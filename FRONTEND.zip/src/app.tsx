import React, { useState } from 'react';
import { fetchStockData } from './api';
import { StockData } from './types';
import StockCard from './components/StockCard';

const App: React.FC = () => {
  const [symbol, setSymbol] = useState('');
  const [stockData, setStockData] = useState<StockData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async () => {
    if (!symbol.trim()) return;

    setLoading(true);
    setError('');
    try {
      const data = await fetchStockData(symbol.toUpperCase());
      setStockData(data);
    } catch (err) {
      setError('Failed to fetch stock data.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4 text-center">
      <h1 className="text-3xl font-bold mb-6">📈 Stock Price Aggregator</h1>
      <div className="flex justify-center gap-2 mb-4">
        <input
          type="text"
          placeholder="Enter stock symbol (e.g., AAPL)"
          value={symbol}
          onChange={(e) => setSymbol(e.target.value)}
          className="p-2 border border-gray-300 rounded-lg w-64"
        />
        <button
          onClick={handleSearch}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700"
        >
          Search
        </button>
      </div>

      {loading && <p>Loading...</p>}
      {error && <p className="text-red-600">{error}</p>}
      {stockData && <StockCard data={stockData} />}
    </div>
  );
};

export default App;
