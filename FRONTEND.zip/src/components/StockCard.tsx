import React from 'react';
import { StockData } from '../types';

interface Props {
  data: StockData;
}

const StockCard: React.FC<Props> = ({ data }) => {
  return (
    <div className="bg-white rounded-2xl shadow-md p-4 w-full max-w-md mx-auto mt-4">
      <h2 className="text-xl font-bold text-blue-700">{data.symbol}</h2>
      <p className="text-lg">💰 {data.price.toFixed(2)} {data.currency}</p>
      <p className="text-sm text-gray-500">📅 {new Date(data.time).toLocaleString()}</p>
    </div>
  );
};

export default StockCard;
