export interface StockData {
  symbol: string;
  price: number;
  currency: string;
  time: string;
}