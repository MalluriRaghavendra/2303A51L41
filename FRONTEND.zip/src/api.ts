import axios from 'axios';
import { StockData } from './types';

export async function fetchStockData(symbol: string): Promise<StockData> {
  const response = await axios.get(`https://api.example.com/stocks/${symbol}`);

  return {
    symbol: response.data.symbol,
    price: response.data.price,
    currency: response.data.currency || 'USD',
    time: response.data.time || new Date().toISOString(),
  };
}
